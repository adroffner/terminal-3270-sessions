""" IBM 3270 Terminal API Client Sessions
"""

__version__ = '0.5b0'
